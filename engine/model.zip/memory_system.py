import json
import re
import threading
from pathlib import Path
import numpy as np
import datetime
import torch
from transformers import AutoTokenizer, AutoModel

# ─── Embedding Model ───────────────────────────────────────────────────────────

HF_MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
LOCAL_MODEL_PATH = Path("model") / "embedding_model" / HF_MODEL_NAME.split("/")[-1]

def _load_embedding_model():
    if LOCAL_MODEL_PATH.exists():
        tok = AutoTokenizer.from_pretrained(LOCAL_MODEL_PATH)
        mdl = AutoModel.from_pretrained(LOCAL_MODEL_PATH)
    else:
        tok = AutoTokenizer.from_pretrained(HF_MODEL_NAME)
        mdl = AutoModel.from_pretrained(HF_MODEL_NAME)
        LOCAL_MODEL_PATH.mkdir(parents=True, exist_ok=True)
        tok.save_pretrained(LOCAL_MODEL_PATH)
        mdl.save_pretrained(LOCAL_MODEL_PATH)
    return tok, mdl

_tokenizer, _model = _load_embedding_model()

def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0]
    mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * mask_expanded, 1) / torch.clamp(
        mask_expanded.sum(1), min=1e-9
    )

def create_embedding(text: str) -> np.ndarray:
    if not text or not text.strip():
        return np.zeros(_model.config.hidden_size)
    encoded = _tokenizer(text, padding=True, truncation=True, return_tensors="pt")
    with torch.no_grad():
        out = _model(**encoded)
    emb = mean_pooling(out, encoded["attention_mask"])
    emb = torch.nn.functional.normalize(emb, p=2, dim=1)
    return emb[0].cpu().numpy()

def _is_zero_embedding(embedding: list) -> bool:
    if not embedding: return True
    return np.allclose(np.array(embedding[:10]), 0.0)

# ─── Key Facts Extractor ─────────────────────────────────────────────────────

_FACT_PATTERNS = [
    (r"\baku\s+suka\s+([a-zA-Z ]{3,40})", "preferensi"),
    (r"\baku\s+gak\s+suka\s+([a-zA-Z ]{3,40})", "preferensi_tidak"),
    (r"\b(mau|pengen|ingin|rencana|bakal|akan)\s+(ke|pergi|nikah|beli|punya|belajar|cari)\s+([a-zA-Z ]{2,40})", "rencana"),
    (r"\b(besok|nanti|kapan-kapan|minggu depan)\s+(kita|aku)\s+([a-zA-Z ]{3,40})", "rencana"),
    (r"\baku\s+(tinggal|kerja|kuliah|sekolah)\s+di\s+([a-zA-Z ]{3,30})", "identitas"),
    (r"\b(hobiku|hobi aku|kesukaanku)\s+(adalah|itu)\s+([a-zA-Z ]{3,40})", "identitas"),
    (r"\b(namaku|nama aku)\s+(adalah|itu)?\s*([a-zA-Z ]{2,30})", "identitas"),
]

def extract_key_facts(conversation: list) -> list:
    facts = []
    seen = set()
    for msg in conversation:
        if msg["role"] != "user": continue
        text = msg["content"].strip()
        if not text or len(text) < 8: continue
        
        for pattern, category in _FACT_PATTERNS:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                val = match.group(0).strip()
                # Clean up known instruction prefixes
                val = re.sub(r"^(ingetin|ingat|tau|tahu|tolong)\s+(bahwa|kalau|kalo)?\s*", "", val, flags=re.I)
                key = f"{category}:{val.lower()}"
                if key not in seen:
                    seen.add(key)
                    facts.append({"category": category, "fact": val, "source": text[:100]})
    return facts

def facts_to_text(facts: list) -> str:
    if not facts: return ""
    by_cat = {}
    for f in facts:
        by_cat.setdefault(f["category"], []).append(f["fact"])
    lines = []
    for cat, items in by_cat.items():
        lines.append(f"• [{cat.capitalize()}] " + "; ".join(items))
    return "\n".join(lines)

# ─── Base Memory ───────────────────────────────────────────────────────────────

class BaseMemory:
    def __init__(self, file_path: Path, default_content):
        self.file_path = file_path
        self._default = default_content
        self._lock = threading.Lock()
        self.data = self._load()

    def _load(self):
        if not self.file_path.exists() or self.file_path.stat().st_size == 0:
            self._write(self._default)
            return self._default
        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            self._write(self._default)
            return self._default

    def _write(self, data):
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def save(self):
        with self._lock: self._write(self.data)

    def save_async(self):
        threading.Thread(target=self.save, daemon=True).start()

# ─── Semantic Memory (Knowledge Store) ─────────────────────────────────────────

class SemanticMemory(BaseMemory):
    def __init__(self, directory: Path):
        super().__init__(directory / "semantic.json", default_content={})

    def add_fact(self, key: str, value: str):
        key = key.lower().strip()
        if self.data.get(key) != value:
            self.data[key] = value
            self.save_async()

    def search(self, query: str) -> str:
        q = query.lower()
        results = []
        for k, v in self.data.items():
            if q in k or any(word in k for word in q.split() if len(word) > 3):
                results.append(f"- {k}: {v}")
        return "\n".join(results[:5])

# ─── Episodic Memory (Conversation Store) ─────────────────────────────────────

class EpisodicMemory(BaseMemory):
    def __init__(self, directory: Path):
        super().__init__(directory / "episodic.json", default_content=[])

    def add(self, conversation: list, llm_summary: str = ""):
        text_conv = " ".join(f"{m['role']}: {m['content']}" for m in conversation if m["content"])
        if not text_conv.strip(): return

        embedding = create_embedding(text_conv).tolist()
        key_facts = extract_key_facts(conversation)
        
        entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "summary": llm_summary.strip(),
            "key_facts": key_facts,
            "embedding": embedding,
            "conversation": [{"role": m["role"], "content": m["content"]} for m in conversation if m["content"]]
        }
        self.data.append(entry)
        if len(self.data) > 100: self.data = self.data[-100:]
        self.save_async()

    def search_contextual(self, query: str, top_k: int = 2) -> list:
        if not self.data or not query: return []
        
        q_emb = create_embedding(query)
        keywords = [w.lower() for w in re.split(r'\W+', query) if len(w) > 2]
        
        scored_results = []
        for entry in self.data:
            emb = entry.get("embedding", [])
            vector_score = float(np.dot(q_emb, np.array(emb))) if not _is_zero_embedding(emb) else 0
            
            keyword_score = 0
            text_pool = (entry.get("summary", "") + " " + 
                         " ".join(f["fact"] for f in entry.get("key_facts", []))).lower()
            for kw in keywords:
                if kw in text_pool: keyword_score += 2
                
            for msg in entry.get("conversation", []):
                if any(kw in msg["content"].lower() for kw in keywords):
                    keyword_score += 1
            
            final_score = (vector_score * 5) + keyword_score
            if final_score > 1.5:
                scored_results.append((final_score, entry))
        
        scored_results.sort(key=lambda x: x[0], reverse=True)
        return [item[1] for item in scored_results[:top_k]]

    def get_recent_facts_text(self, n_sessions: int = 3, max_facts: int = 8) -> str:
        sessions = self.data[-n_sessions:]
        all_facts = []
        for s in sessions:
            all_facts.extend(s.get("key_facts", []))
        return facts_to_text(all_facts[:max_facts])

# ─── Core Memory (Identity) ────────────────────────────────────────────────────

class CoreMemory(BaseMemory):
    def __init__(self, directory: Path):
        super().__init__(directory / "core_memory.json", default_content={"summary": "", "user_profile": {}})

    def get_context_text(self) -> str:
        parts = []
        if self.data.get("summary"):
            parts.append(f"[Profil Utama]\n{self.data['summary']}")
        profile = self.data.get("user_profile", {})
        if profile.get("preferensi"):
            parts.append("Preferensi: " + ", ".join(profile["preferensi"][:10]))
        return "\n".join(parts)

# ─── Hybrid Memory (Orchestrator) ──────────────────────────────────────────────

class HybridMemory:
    def __init__(self, episodic: EpisodicMemory, core: CoreMemory, semantic: SemanticMemory):
        self.episodic = episodic
        self.core = core
        self.semantic = semantic
        self.live_buffer = []

    def update_live_facts(self, conversation: list):
        new_facts = extract_key_facts(conversation)
        for f in new_facts:
            if f not in self.live_buffer:
                self.live_buffer.append(f)

    def extract_and_save_preferences(self, conversation: list):
        self.update_live_facts(conversation)
        for f in self.live_buffer:
            if f["category"] == "preferensi":
                prefs = self.core.data.setdefault("user_profile", {}).setdefault("preferensi", [])
                if f["fact"] not in prefs:
                    prefs.append(f["fact"])
                    self.core.save_async()

    def get_hint_for_thought(self, query: str) -> str:
        parts = []
        core_sum = self.core.data.get("summary", "")
        if core_sum: parts.append(f"Asta tahu: {core_sum[:150]}")
        
        if self.live_buffer:
            live = "; ".join(f["fact"] for f in self.live_buffer[-3:])
            parts.append(f"Baru saja dibahas: {live}")
            
        last_sessions = self.episodic.data[-2:]
        if last_sessions:
            summaries = [s.get("summary") for s in last_sessions if s.get("summary")]
            if summaries: parts.append("Topik sebelumnya: " + " | ".join(summaries))
            
        return "\n".join(parts) if parts else "(Belum ada ingatan relevan)"

    def get_full_context(self, query: str, recall_topic: str = "") -> str:
        target = recall_topic if recall_topic and len(recall_topic) > 2 else query
        if not target: return ""
        
        parts = []
        sem_results = self.semantic.search(target)
        if sem_results: parts.append(f"[Pengetahuan Terkait]\n{sem_results}")
        
        episodes = self.episodic.search_contextual(target)
        for ep in episodes:
            snippet = []
            conv = ep.get("conversation", [])
            keywords = [w.lower() for w in re.split(r'\W+', target) if len(w) > 2]
            found_idx = -1
            for i, m in enumerate(conv):
                if any(kw in m["content"].lower() for kw in keywords):
                    found_idx = i
                    break
            
            if found_idx != -1:
                start = max(0, found_idx - 1)
                end = min(len(conv), found_idx + 2)
                for m in conv[start:end]:
                    role = "Aditiya" if m["role"] == "user" else "Asta"
                    snippet.append(f"{role}: {m['content']}")
                ts = ep.get("timestamp", "")[:10]
                parts.append(f"[Percakapan {ts}]\n" + "\n".join(snippet))
        
        return "\n\n".join(parts)

    def get_context(self, current_query: str = "", recall_topic: str = "", max_chars: int = 1200) -> str:
        return self.get_full_context(current_query, recall_topic)

    def update_core_async(self, llm_callable, current_session_text: str):
        def _worker():
            old_summary = self.core.data.get("summary", "")
            prompt = (
                "Berdasarkan ringkasan lama dan chat baru, buat satu paragraf (maks 100 kata) "
                "tentang fakta penting user (nama, hobi, rencana). Bahasa Indonesia.\n\n"
                f"Lama: {old_summary}\nBaru: {current_session_text[:1000]}\n\nRingkasan Baru:"
            )
            try:
                res = llm_callable(prompt=prompt, max_tokens=200, temperature=0.2)
                summary = res["choices"][0]["text"].strip()
                if summary:
                    self.core.data["summary"] = summary
                    self.core.save()
                    print("[Core Memory] Updated.")
            except: pass
        threading.Thread(target=_worker, daemon=False).start()
