from pathlib import Path
from .memory_system import SemanticMemory, EpisodicMemory, CoreMemory, HybridMemory

MEMORY_DIR = Path("memory")
MEMORY_DIR.mkdir(exist_ok=True)

semantic_memory = SemanticMemory(MEMORY_DIR)
episodic_memory = EpisodicMemory(MEMORY_DIR)
core_memory = CoreMemory(MEMORY_DIR)
# Update signature to include semantic
hybrid_memory = HybridMemory(episodic=episodic_memory, core=core_memory, semantic=semantic_memory)

# ─── Semantic / Identity ──────────────────────────────────────────────────────

def remember_identity(key: str, value):
    semantic_memory.add_fact(key, value)

def get_identity(key: str):
    # Semantic memory uses data dict directly in the new version
    return semantic_memory.data.get(key.lower())

def get_all_identities() -> dict:
    return semantic_memory.data.copy()

# ─── Episodic ─────────────────────────────────────────────────────────────────

def add_episodic(conversation: list, llm_summary: str = ""):
    episodic_memory.add(conversation, llm_summary=llm_summary)

def search_episodic(query: str, top_k: int = 3) -> list:
    return episodic_memory.search_contextual(query, top_k=top_k)

def get_last_episodic_sessions(n: int = 3) -> list:
    return episodic_memory.get_last_n(n)

# ─── Core Memory ─────────────────────────────────────────────────────────────

def get_core_memory() -> str:
    # Use core.data.get('summary') since CoreMemory was refactored
    return core_memory.data.get("summary", "")

def save_core_memory(text: str):
    core_memory.data["summary"] = text
    core_memory.save()

# ─── Hybrid ──────────────────────────────────────────────────────────────────

def get_hybrid_memory() -> HybridMemory:
    return hybrid_memory

def get_memory_hint(query: str = "") -> str:
    return hybrid_memory.get_hint_for_thought(query)

def get_memory_full(query: str = "", recall_topic: str = "") -> str:
    return hybrid_memory.get_full_context(query, recall_topic)
